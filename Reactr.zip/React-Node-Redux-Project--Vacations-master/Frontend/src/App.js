import React, { Component } from 'react';
import Main from './components/common/Main';



class App extends Component {
  render() {
    return (
        <Main/>
    );
  }
}

export default App;
