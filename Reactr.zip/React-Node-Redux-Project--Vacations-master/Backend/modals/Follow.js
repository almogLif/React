
module.exports= function Follow(vacationID,follow){
    this.firstName=firstName ? firstName : null;
    this.lastName=lastName ? lastName : null;
};
